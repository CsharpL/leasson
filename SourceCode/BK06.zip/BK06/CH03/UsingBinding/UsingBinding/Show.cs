﻿using System;

namespace UsingBinding
{
    public class Show
    {
        public int ID { get; set; }
        public String ShowTitle { get; set; }
        public String EpisodeTitle { get; set; }
        public DateTime ScheduledTime { get; set; }
        public int Channel { get; set; }
    }
}