﻿using System;

namespace WebControls
{
    public partial class Images : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Image1.ImageUrl = "Colorblk3.jpg";
        }
    }
}