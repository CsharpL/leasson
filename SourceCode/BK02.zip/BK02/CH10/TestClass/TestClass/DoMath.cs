﻿using System;

namespace TestClass
{
    public class DoMath
    {
        public int DoAdd(int Num1, int Num2)
        {
            return Num1 + Num2;
        }

        public int DoSub(int Num1, int Num2)
        {
            return Num1 - Num2;
        }

        public int DoMul(int Num1, int Num2)
        {
            return Num1 * Num2;
        }

        public int DoDiv(int Num1, int Num2)
        {
            return Num1 / Num2;
        }
    }
}
